import type { DevTreeLinks } from '../types';
import { Switch } from '@headlessui/react';
import { classNames } from '../utils';

type DevTreeInputProps = {
    item: DevTreeLinks;
    handleUrlChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    handleEnableLink: (name: string) => void;
}

export const DevTreeInput = ({ item, handleUrlChange, handleEnableLink }: DevTreeInputProps) => {
    return (
        <div className='flex items-center gap-5 p-5 bg-white rounded-lg shadow-md'>
            <div className='w-12 h-12 bg-cover'
                style={{ backgroundImage: `url(/social/${item.name}.svg)` }}>
            </div>
            <input type="text" placeholder={`Enter ${item.name} URL`}
                    value={item.url}
                    onChange={handleUrlChange}
                    name={item.name}
                    className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <Switch
                checked={item.enabled}
                onChange={() => handleEnableLink(item.name)}
                className={classNames(
                    item.enabled ? 'bg-blue-500' : 'bg-gray-200',
                    'relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2'
                )}
            >
                <span
                    aria-hidden="true"
                    className={classNames(
                        item.enabled ? 'translate-x-5' : 'translate-x-0',
                        'pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out'
                    )}
                />
            </Switch>
        </div>
    )
}
