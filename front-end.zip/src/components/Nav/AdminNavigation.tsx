import { useQueryClient } from "@tanstack/react-query";


export const AdminNavigation = () => {
  const queryClient = useQueryClient();

  const logout = () => {
    localStorage.removeItem('AUTH_TOKEN');
    queryClient.invalidateQueries();
  }

  return (
    <button
        className="p-2 text-xs font-black uppercase rounded-lg cursor-pointer bg-lime-500 text-slate-800"
        onClick={logout}
    >
        Cerrar Sesión
    </button>
  )
}
